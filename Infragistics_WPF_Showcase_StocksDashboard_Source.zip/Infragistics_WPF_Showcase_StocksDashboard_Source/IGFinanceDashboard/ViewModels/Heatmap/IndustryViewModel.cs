﻿namespace IGShowcase.FinanceDashboard.ViewModels
{
    public class IndustryViewModel : StockDataViewModel
    {
    }
}
