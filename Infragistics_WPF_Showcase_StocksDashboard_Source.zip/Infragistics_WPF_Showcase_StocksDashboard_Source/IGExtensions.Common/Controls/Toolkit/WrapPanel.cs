
namespace IGExtensions.Common.Controls
{
    /// <summary>
    /// Represents common <see cref="System.Windows.Controls.WrapPanel"/> control wrapper for SL and WPF
    /// </summary>
    public class WrapPanel : System.Windows.Controls.WrapPanel
    {
        
    }
}