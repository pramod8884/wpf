
namespace IGExtensions.Common.Controls
{
    /// <summary>
    /// Represents common <see cref="System.Windows.Controls.Expander"/> control wrapper for SL and WPF
    /// </summary>
    public class Expander : System.Windows.Controls.Expander
    {
        
    }
}