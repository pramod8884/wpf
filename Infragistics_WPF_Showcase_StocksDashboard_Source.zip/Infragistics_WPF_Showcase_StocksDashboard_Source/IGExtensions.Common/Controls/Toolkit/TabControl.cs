namespace IGExtensions.Common.Controls
{
    /// <summary>
    /// Represents common <see cref="System.Windows.Controls.TabControl"/> control wrapper for SL and WPF
    /// </summary>
    public class TabControl : System.Windows.Controls.TabControl
    {
        
    }
    /// <summary>
    /// Represents common <see cref="System.Windows.Controls.TabItem"/> control wrapper for SL and WPF
    /// </summary>
    public class TabItem : System.Windows.Controls.TabItem
    {
        
    }
    ///// <summary>
    ///// Represents common <see cref="System.Windows.Controls.TabItem"/> control wrapper for SL and WPF
    ///// </summary>
    public class TabPanel : System.Windows.Controls.Primitives.TabPanel
    {

    }
    

    

}