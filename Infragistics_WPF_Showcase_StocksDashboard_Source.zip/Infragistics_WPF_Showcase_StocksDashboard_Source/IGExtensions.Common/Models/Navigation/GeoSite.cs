namespace IGExtensions.Common.Models
{
    public class GeoSite : GeoPoint
    {
        public string Name { get; set; }
    
    }
}