﻿using System.Resources;
using System.Reflection; 

[assembly: AssemblyTitle(AssemblyDesigner.TitlePrefix +        "Framework.CrossPlatform")]
[assembly: AssemblyProduct(AssemblyDesigner.ProductPrefix +    "Framework.CrossPlatform")]
[assembly: AssemblyDescription(AssemblyDesigner.DescrPrefix +  "Framework.CrossPlatform")]
[assembly: AssemblyCopyright(AssemblyDesigner.Copyright)]
[assembly: AssemblyCompany(AssemblyDesigner.CompanyName)]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: AssemblyVersion(AssemblyDesigner.Version)]
[assembly: AssemblyFileVersion(AssemblyDesigner.Version)]

[assembly: NeutralResourcesLanguage("en")]