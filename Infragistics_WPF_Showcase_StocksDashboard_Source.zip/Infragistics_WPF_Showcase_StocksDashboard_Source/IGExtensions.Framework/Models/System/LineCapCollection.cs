using System.Collections.Generic;
using System.Windows.Media;

namespace IGExtensions.Framework.Models
{
    public class LineCapCollection : List<PenLineCap>
    {

    }
}