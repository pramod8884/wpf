using System.Collections.ObjectModel;
using System.Windows.Media;

namespace IGExtensions.Framework.Models
{
    public class ImageBrushCollection : ObservableCollection<ImageBrush>
    {

    }
}