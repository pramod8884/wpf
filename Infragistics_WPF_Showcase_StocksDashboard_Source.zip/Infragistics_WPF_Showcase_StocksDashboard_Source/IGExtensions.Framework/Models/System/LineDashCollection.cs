using System.Collections.Generic;

namespace IGExtensions.Framework.Models
{
    public class LineDashCollection : StringCollection
    {

    }
}