using System.Collections.Generic;
using System.Collections.ObjectModel;

namespace IGExtensions.Framework.Models
{
    public class StringCollection : ObservableCollection<string>
    {

    }
    public class StringList : List<string>
    {

    }
}