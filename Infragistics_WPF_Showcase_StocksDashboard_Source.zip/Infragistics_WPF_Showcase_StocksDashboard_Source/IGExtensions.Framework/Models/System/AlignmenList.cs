using System.Collections.Generic;
using System.Windows;

namespace IGExtensions.Framework.Models
{
    public class HorizontalAlignmenList : List<HorizontalAlignment>
    {

    }
    public class VerticalAlignmentList : List<VerticalAlignment>
    {

    }
}