using System.Windows.Controls;  // System.Windows.Controls.Navigation

namespace IGExtensions.Framework.Controls
{
    /// <summary>
    /// Represents common XAML wrapper for <see cref="System.Windows.Controls.Frame"/>
    /// </summary>
    public class NavigationFrame : Frame
    {
        
    }
}